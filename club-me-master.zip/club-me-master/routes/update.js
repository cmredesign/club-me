
exports.view = function(req, res){
  console.log("first one");
  res.render('updateprofile');
}
