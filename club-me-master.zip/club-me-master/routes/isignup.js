
exports.view = function(req, res){
  res.render('isignup');
}
